$( document ).ready(function() {
    KTWizard2.init();
});